import { createContext, useState, useEffect } from 'react';
import { initializeSocket } from '../config/socket';

export const SocketContext = createContext();

export const SocketProvider = ({ children }) => {
    const [socket, setSocket] = useState(null);
    const [currentProjectId, setCurrentProjectId] = useState(null);

    const connectSocket = (projectId) => {
        if (currentProjectId !== projectId) {
            if (socket) {
                socket.disconnect();
            }
            const newSocket = initializeSocket(projectId);
            setSocket(newSocket);
            setCurrentProjectId(projectId);
            return newSocket;
        }
        return socket;
    };

    useEffect(() => {
        return () => {
            if (socket) {
                socket.disconnect();
                setSocket(null);
                setCurrentProjectId(null);
            }
        };
    }, [socket]);

    return (
        <SocketContext.Provider value={{ 
            socket, 
            connectSocket,
            currentProjectId 
        }}>
            {children}
        </SocketContext.Provider>
    );
};