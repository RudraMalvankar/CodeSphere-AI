
import AppRoutes from './routes/AppRoutes'
import { UserProvider } from './context/user.context'
import { SocketProvider } from './context/socket.context'

const App = () => {
  return (
    <UserProvider>
      <SocketProvider>
        <AppRoutes />
      </SocketProvider>
    </UserProvider>
  )
}

export default App